from django.contrib import admin
from .models import Generos, Filmes
from rest_framework.authtoken.models import Token

# Admin para o modelo Generos: mostra o campo 'nome' e permite busca por nome
@admin.register(Generos)
class GenerosAdmin(admin.ModelAdmin):
   list_display = [ 'nome' ] # adicione os campos da listagem
   search_fields = [ 'nome' ] # adicione os campos da pesquisa


@admin.register(Filmes)
class FilmeAdmin(admin.ModelAdmin):
  list_display = [ 'titulo' ] # adicione os campos da listagem     
  search_fields = [ 'titulo' ] # adicione os campos da pesquisa
  list_filter = [ 'genero' ] # adicione os campos dos filtros laterais da página

admin.site.register(Token)
